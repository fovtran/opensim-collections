#
# Copyright (c) 2010, 2018 Oracle and/or its affiliates. All rights reserved.
#
# This program and the accompanying materials are made available under the
# terms of the Eclipse Distribution License v. 1.0, which is available at
# http://www.eclipse.org/org/documents/edl-v10.php.
#
# SPDX-License-Identifier: BSD-3-Clause
#

This example basically dumpts the contents of parsed schemas.
The SchemaWriter class is already in xsom.jar, so you don't need
to compile that file. Its source code is here just for your reference.

To run the example:

    $ javac *.java
    $ java Dumper <some schema>
