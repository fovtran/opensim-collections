<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>{{ $meta_title.' - '.$site_name }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="{{ $meta_description }}">
    <meta name="keywords" content="{{ $meta_keywords }}">

    <!-- Le styles -->
    <link href="{{ URL::base() }}/themes/bare_bones/assets/css/style.css" rel="stylesheet">
    
    <!-- containers used by modules to automatically load assets -->
    {{ Asset::styles() }}
    {{ Asset::container('header')->styles() }}
    {{ Asset::container('page')->styles() }}

    {{ Asset::scripts() }}
    {{ Asset::container('header')->scripts() }}
    {{ Asset::container('page')->scripts() }}

    <!-- Fav icons -->
    <link rel="shortcut icon" href="{{ URL::base() }}/themes/bare_bones/assets/img/ico/favicon.ico">
  </head>

  <body>

    {{ themes\render_partial('header_nav') }}

    <div class="container-fluid">
      <div class="row-fluid">
        
        <div class="span3">

        {{ themes\render_partial('sidebar_nav') }}

        </div><!--/span-->
        
        <div style="min-height:200px; margin-top:15px;" class="span9">

          <div id="flash-message" class="flash-message">
            @if (Session::has('message'))
            <div class="alert alert-{{ Session::get('message_type') }} fade in">
              <button data-dismiss="alert" class="close" type="button">×</button>
              {{ Session::get('message') }}
            </div>
            @endif

            @if( !empty($errors->messages) )
            <div class="alert alert-error fade in">
              <button data-dismiss="alert" class="close" type="button">×</button>
              {{ $errors->first() }}
            </div>
            @endif
          </div>
          
          {{ $theme_content }}

        </div><!--/span-->

      </div><!--/row-->

      <div>

        {{ themes\render_partial('footer') }}
        
      </div>

    </div><!--/.fluid-container-->

    <!-- Le javascript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    {{ Asset::container('footer')->scripts() }}
    {{ Asset::container('after_footer')->scripts() }}
  </body>
</html>