<ul>
    {{ \IoC::resolve('Menu')->get_nav('sidebar') }}
</ul>