<ul>
    {{ \IoC::resolve('Menu')->get_nav('footer') }}
</ul>