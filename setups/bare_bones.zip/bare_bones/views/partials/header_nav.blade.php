<ul>
    {{ \IoC::resolve('Menu')->get_nav('header') }}
</ul>